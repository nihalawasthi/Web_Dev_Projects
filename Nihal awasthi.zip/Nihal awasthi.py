class ATM:
    def __init__(self, user_id, pin):
        self.user_id = user_id
        self.pin = pin
        self.balance = 1000  # Initial balance (you can set this to any value)
        self.transaction_history = []

    def authenticate(self, entered_pin):
        # Check if the entered PIN matches the user's PIN
        if entered_pin == self.pin:
            return True
        else:
            return False

    def view_transaction_history(self):
        print("\nTransaction History:")
        for transaction in self.transaction_history:
            print(transaction)

    def withdraw(self, amount):
        if amount <= 0:
            print("Invalid amount. Please enter a positive value.")
            return

        if amount > self.balance:
            print("Insufficient balance.")
        else:
            self.balance -= amount
            self.transaction_history.append(f"Withdrew ${amount:.2f}")
            print(f"Withdrew ${amount:.2f}. New balance: ${self.balance:.2f}")

    def deposit(self, amount):
        if amount <= 0:
            print("Invalid amount. Please enter a positive value.")
            return

        self.balance += amount
        self.transaction_history.append(f"Deposited ${amount:.2f}")
        print(f"Deposited ${amount:.2f}. New balance: ${self.balance:.2f}")

    def transfer(self, recipient, amount):
        if amount <= 0:
            print("Invalid amount. Please enter a positive value.")
            return

        if amount > self.balance:
            print("Insufficient balance.")
        else:
            self.balance -= amount
            self.transaction_history.append(f"Transferred ${amount:.2f} to {recipient}")
            print(f"Transferred ${amount:.2f} to {recipient}. New balance: ${self.balance:.2f}")

def main():
    # Initialize ATM and authentication
    user_id = input("Enter User ID: ")
    pin = input("Enter PIN: ")
    atm = ATM(user_id, pin)
    
    if not atm.authenticate(pin):
        print("Authentication failed. Exiting...")
        return

    while True:
        # Display menu and handle user input
        print("\nMenu:")
        print("1. View Transaction History")
        print("2. Withdraw")
        print("3. Deposit")
        print("4. Transfer")
        print("5. Quit")

        choice = input("Select an option: ")

        if choice == '1':
            atm.view_transaction_history()
        elif choice == '2':
            amount = float(input("Enter withdrawal amount: "))
            atm.withdraw(amount)
        elif choice == '3':
            amount = float(input("Enter deposit amount: "))
            atm.deposit(amount)
        elif choice == '4':
            recipient = input("Enter recipient's User ID: ")
            amount = float(input("Enter transfer amount: "))
            atm.transfer(recipient, amount)
        elif choice == '5':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
